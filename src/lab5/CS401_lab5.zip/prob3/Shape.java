package lab5.prob3;

public interface Shape {
    double getArea();
}
